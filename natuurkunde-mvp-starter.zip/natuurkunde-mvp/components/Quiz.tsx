'use client'
import { useEffect, useState } from 'react'
import { decidePath } from '@/lib/adaptive'
import { supabase } from '@/lib/supabaseClient'
import type { QuizItem } from '@/lib/types'

const bank: Record<string, QuizItem[]> = {
  'qb-speed-01': [
    { id: 'q1', stem: 'Reken 36 km/h om naar m/s.', type: 'num', answer: 10, tolerance: 0.1, hint: 'Deel door 3,6.' },
    { id: 'q2', stem: 'Een auto rijdt 1500 m in 75 s. Wat is v (m/s)?', type: 'num', answer: 20, tolerance: 0.1 },
    { id: 'q3', stem: 'Wat is juist?', type: 'mc', options: [
      { key: 'a', label: 'v = t/s' },
      { key: 'b', label: 'v = s·t' },
      { key: 'c', label: 'v = s/t' }
    ], answer: 'c', hint: 'Denk aan eenheden.' },
    { id: 'q4', stem: 'Fietstocht: s=3600 m, t=720 s. v in km/h?', type: 'num', answer: 18, tolerance: 0.2 },
    { id: 'q5', stem: 'Kies de SI-eenheid voor snelheid.', type: 'mc', options: [
      { key: 'a', label: 'km/h' }, { key: 'b', label: 'm/s' }, { key: 'c', label: 'm·s' }
    ], answer: 'b' },
    { id: 'q6', stem: 'Een renner loopt 400 m in 50 s. v (m/s)?', type: 'num', answer: 8, tolerance: 0.1 }
  ]
}

function evaluate(item: QuizItem, resp: string): { correct: boolean; commonError?: string } {
  if (item.type === 'mc') return { correct: resp === String(item.answer) }
  const val = Number(resp.replace(',', '.'))
  if (Number.isNaN(val)) return { correct: false }
  const tol = item.tolerance ?? 0
  const ok = Math.abs(val - Number(item.answer)) <= tol
  const commonError = !ok && Math.abs(val - Number(item.answer) * 3.6) <= (tol + 0.1) ? 'units' : undefined
  return { correct: ok, commonError }
}

export default function Quiz({ bankRef, moduleId }: { bankRef: string; moduleId: string }) {
  const items = bank[bankRef]
  const [idx, setIdx] = useState(0)
  const [resp, setResp] = useState('')
  const [score, setScore] = useState(0)
  const [errors, setErrors] = useState<string[]>([])
  const [start] = useState(Date.now())

  const item = items[idx]

  const onSubmit = async () => {
    const { correct, commonError } = evaluate(item, resp)
    setScore(s => s + (correct ? 1 : 0))
    if (!correct && commonError) setErrors(e => [...e, commonError])
    if (idx < items.length - 1) setIdx(i => i + 1)
    setResp('')
  }

  const finished = idx >= items.length - 1

  useEffect(() => {
    if (!finished) return
    const duration = (Date.now() - start) / 1000
    const p = decidePath(score / items.length, duration, errors.includes('units') ? 'units' : undefined)
    // Save attempt (anoniem per user-id)
    supabase.from('attempts').insert({ module_id: moduleId, score, total: items.length, duration_s: Math.round(duration), next_path: p })
  }, [finished])

  return (
    <section className="p-4 border rounded-xl space-y-3">
      <h3 className="font-semibold">Quiz</h3>
      <div className="font-medium">{item.stem}</div>
      {item.type === 'mc' ? (
        <div className="space-y-2">
          {item.options!.map(o => (
            <label key={o.key} className="flex items-center gap-2">
              <input type="radio" name="mc" onChange={() => setResp(o.key)} checked={resp===o.key} />{o.label}
            </label>
          ))}
        </div>
      ) : (
        <input className="border p-2 rounded w-40" value={resp} onChange={e=>setResp(e.target.value)} placeholder="antwoord" />
      )}
      <div className="flex gap-2">
        <button className="border px-3 py-1 rounded" onClick={onSubmit}>Check</button>
      </div>
      <div className="text-sm text-gray-600">{idx+1} / {items.length}</div>
    </section>
  )
}
