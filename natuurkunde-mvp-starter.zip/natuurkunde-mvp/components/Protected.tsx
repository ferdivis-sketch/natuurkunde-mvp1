'use client'
import { supabase } from '@/lib/supabaseClient'
import { useEffect, useState } from 'react'
import Link from 'next/link'

export default function Protected({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setLoading(false)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s))
    return () => sub.subscription.unsubscribe()
  }, [])
  if (loading) return <div className="p-6">Laden…</div>
  if (!session) return (
    <div className="p-6">
      <p>Je moet eerst inloggen.</p>
      <Link href="/login" className="underline">Ga naar login</Link>
    </div>
  )
  return <>{children}</>
}
