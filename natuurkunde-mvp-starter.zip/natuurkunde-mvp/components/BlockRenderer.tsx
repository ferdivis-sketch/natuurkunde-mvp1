'use client'
import { Block } from '@/lib/types'
import Quiz from './Quiz'
import { KaTeX } from '@/lib/katex'

export default function BlockRenderer({ block, moduleId }: { block: Block; moduleId: string }) {
  if (block.type === 'context' || block.type === 'example') {
    return <section className="p-4 border rounded-xl whitespace-pre-wrap">{(block as any).md}</section>
  }
  if (block.type === 'theory') {
    return <section className="p-4 border rounded-xl"><KaTeX tex={(block as any).md} /></section>
  }
  if (block.type === 'simulation') {
    const b = block as any
    const url = `https://phet.colorado.edu/sims/html/moving-man/latest/moving-man_all.html`
    return (
      <section className="p-4 border rounded-xl space-y-2">
        <iframe src={url} className="w-full h-96 border rounded" />
        {b.prompts?.length ? (
          <ul className="list-disc pl-6 text-sm">
            {b.prompts.map((p: string, i: number) => <li key={i}>{p}</li>)}
          </ul>
        ) : null}
      </section>
    )
  }
  if (block.type === 'quiz') {
    // @ts-expect-error server->client boundary type
    return <Quiz bankRef={(block as any).bankRef} moduleId={moduleId} />
  }
  if (block.type === 'exit_ticket') {
    const b = block as any
    return (
      <section className="p-4 border rounded-xl">
        <h3 className="font-semibold mb-2">Exit ticket</h3>
        <ol className="list-decimal pl-6 space-y-1">{b.items.map((q: string, i: number) => <li key={i}>{q}</li>)}</ol>
      </section>
    )
  }
  return null
}
