'use client'
import { FormEvent, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const onSubmit = async (e: FormEvent) => {
    e.preventDefault()
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: window.location.origin } })
    if (!error) setSent(true)
    else alert(error.message)
  }
  return (
    <main className="max-w-md mx-auto p-6 space-y-4">
      <h1 className="text-xl font-semibold">Inloggen</h1>
      {sent ? (
        <p>Check je e-mail voor de inloglink.</p>
      ) : (
        <form onSubmit={onSubmit} className="space-y-3">
          <input className="border p-2 w-full rounded" placeholder="jij@school.nl" value={email} onChange={e=>setEmail(e.target.value)} />
          <button className="border px-4 py-2 rounded" type="submit">Stuur magic link</button>
        </form>
      )}
    </main>
  )
}
