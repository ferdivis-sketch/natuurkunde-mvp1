import fs from 'node:fs'
import path from 'node:path'
import Link from 'next/link'

export default async function Page() {
  const file = path.join(process.cwd(), 'content/modules/beweging-snelheid.json')
  const mod = JSON.parse(fs.readFileSync(file, 'utf-8'))
  return (
    <main className="max-w-3xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Digitale Natuurkunde – Modules</h1>
      <ul className="space-y-3">
        <li className="p-4 border rounded-xl">
          <div className="font-semibold">{mod.title}</div>
          <div className="text-sm text-gray-600">Niveau: {mod.level}</div>
          <Link className="inline-block mt-2 underline" href={`/module/${mod.id}`}>Open</Link>
        </li>
      </ul>
    </main>
  )
}
