import fs from 'node:fs'
import path from 'node:path'
import { notFound } from 'next/navigation'
import BlockRenderer from '@/components/BlockRenderer'
import Protected from '@/components/Protected'

export default async function ModulePage({ params }: { params: { id: string } }) {
  const file = path.join(process.cwd(), `content/modules/beweging-snelheid.json`)
  if (!fs.existsSync(file)) return notFound()
  const mod = JSON.parse(fs.readFileSync(file, 'utf-8'))
  if (mod.id !== params.id) return notFound()

  return (
    <Protected>
      <main className="max-w-3xl mx-auto p-6 space-y-6">
        <h1 className="text-2xl font-bold">{mod.title}</h1>
        {mod.blocks.map((b: any, i: number) => (
          // @ts-expect-error server->client boundary type
          <BlockRenderer key={i} block={b} moduleId={mod.id} />
        ))}
      </main>
    </Protected>
  )
}
