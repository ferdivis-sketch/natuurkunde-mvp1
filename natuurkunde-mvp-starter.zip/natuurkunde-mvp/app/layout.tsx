import './styles.css'
import '../styles/globals.css'
import Link from 'next/link'

export const metadata = { title: 'Digitale Natuurkunde' }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="nl">
      <body>
        <header className="border-b">
          <nav className="max-w-3xl mx-auto p-4 flex gap-4">
            <Link href="/">Modules</Link>
            <Link href="/login">Login</Link>
          </nav>
        </header>
        {children}
      </body>
    </html>
  )
}
