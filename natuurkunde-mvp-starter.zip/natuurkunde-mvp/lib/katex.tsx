'use client'
import 'katex/dist/katex.min.css'
import Katex from 'katex'
import { useEffect, useRef } from 'react'

export function KaTeX({ tex }: { tex: string }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!ref.current) return
    ref.current.innerHTML = ''
    Katex.render(tex, ref.current, { displayMode: true, throwOnError: false })
  }, [tex])
  return <div ref={ref} />
}
