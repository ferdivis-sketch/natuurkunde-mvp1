export type Block =
  | { type: 'context'; md: string }
  | { type: 'theory'; md: string }
  | { type: 'example'; md: string }
  | { type: 'simulation'; provider: 'phet'; simId: string; prompts?: string[] }
  | { type: 'quiz'; engine: 'adaptive'; bankRef: string }
  | { type: 'exit_ticket'; items: string[] }

export type Module = {
  id: string
  title: string
  level: 'MAVO' | 'HAVO' | 'MAVO|HAVO'
  goals: string[]
  blocks: Block[]
  meta: { tags: string[]; est_time_min: number }
}

export type QuizItem = {
  id: string
  stem: string
  type: 'mc' | 'num'
  options?: { key: string; label: string }[]
  answer: string | number
  tolerance?: number
  hint?: string
}
