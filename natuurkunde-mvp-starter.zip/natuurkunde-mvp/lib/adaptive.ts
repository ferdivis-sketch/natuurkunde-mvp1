export type Path = 'V' | 'M' | 'H'

export function decidePath(score: number, timeOnTaskSec: number, commonError?: string): Path {
  if (score >= 0.8 && timeOnTaskSec >= 60) return 'H'
  if (score < 0.5 || commonError === 'units') return 'V'
  return 'M'
}
